/**
 * Hardened entry point for POST /api/convert-whiteboard-image.
 * Adds: origin check, content-type + size limits, magic-byte image validation,
 * dimension clamping, per-IP rate limiting and generic error messages.
 *
 * NOTE: the rate limiter is in-memory, so on serverless hosts it is best-effort
 * (each warm instance keeps its own counters). For a hard limit use your host's
 * firewall / Upstash Redis, and always set a spend cap on the Google API key.
 */
import { convertWhiteboardImage, UserFacingError } from "./image-converter";

const MAX_BODY_BYTES = 4_000_000; // Vercel serverless request limit is ~4.5 MB
const MAX_DIMENSION = 4096;
const WINDOW_MS = 10 * 60 * 1000;
const MAX_REQUESTS_PER_WINDOW = Number(process.env["CONVERT_RATE_LIMIT"]) || 10;

const hits = new Map<string, number[]>();

function json(body: unknown, status: number, extra: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
      ...extra,
    },
  });
}

function clientIp(request: Request): string {
  const h = request.headers;
  return (
    h.get("cf-connecting-ip") ||
    h.get("x-real-ip") ||
    (h.get("x-forwarded-for") || "").split(",")[0]?.trim() ||
    "unknown"
  );
}

function checkRateLimit(ip: string): number {
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  if (recent.length >= MAX_REQUESTS_PER_WINDOW) {
    hits.set(ip, recent);
    return Math.ceil((WINDOW_MS - (now - (recent[0] ?? now))) / 1000);
  }
  recent.push(now);
  hits.set(ip, recent);
  if (hits.size > 5000) {
    for (const [k, v] of hits) {
      if (v.every((t) => now - t >= WINDOW_MS)) hits.delete(k);
    }
  }
  return 0;
}

function originAllowed(request: Request): boolean {
  const origin = request.headers.get("origin");
  if (!origin) return true; // same-origin fetches from some browsers omit it
  let originHost: string;
  try {
    originHost = new URL(origin).host;
  } catch {
    return false;
  }
  const ownHost =
    request.headers.get("x-forwarded-host") ||
    request.headers.get("host") ||
    new URL(request.url).host;
  if (originHost === ownHost) return true;
  const extra = (process.env["ALLOWED_ORIGINS"] || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  return extra.some((o) => {
    try {
      return new URL(o).host === originHost;
    } catch {
      return false;
    }
  });
}

/** Detects the real image type from the first bytes; never trusts the client's mimeType. */
function sniffMime(b64: string): "image/png" | "image/jpeg" | "image/webp" | null {
  let bin = "";
  try {
    bin = atob(b64.slice(0, 24));
  } catch {
    return null;
  }
  if (bin.startsWith("\x89PNG")) return "image/png";
  if (bin.charCodeAt(0) === 0xff && bin.charCodeAt(1) === 0xd8 && bin.charCodeAt(2) === 0xff) {
    return "image/jpeg";
  }
  if (bin.startsWith("RIFF") && bin.slice(8, 12) === "WEBP") return "image/webp";
  return null;
}

function clampDim(v: unknown, fallback: number): number {
  const n = Math.round(Number(v));
  if (!Number.isFinite(n) || n < 1) return fallback;
  return Math.min(MAX_DIMENSION, n);
}

export async function handleConvertRequest(request: Request): Promise<Response> {
  if (request.method !== "POST") {
    return json({ error: "Method not allowed" }, 405, { allow: "POST" });
  }
  if (!originAllowed(request)) return json({ error: "Forbidden" }, 403);

  const ctype = request.headers.get("content-type") || "";
  if (!ctype.toLowerCase().includes("application/json")) {
    return json({ error: "Expected a JSON request" }, 415);
  }

  const declared = Number(request.headers.get("content-length"));
  if (Number.isFinite(declared) && declared > MAX_BODY_BYTES) {
    return json({ error: "Image is too large. Please use a smaller image." }, 413);
  }

  const retryAfter = checkRateLimit(clientIp(request));
  if (retryAfter > 0) {
    return json({ error: "Too many conversions. Please try again later." }, 429, {
      "retry-after": String(retryAfter),
    });
  }

  try {
    const text = await request.text();
    if (text.length > MAX_BODY_BYTES) {
      return json({ error: "Image is too large. Please use a smaller image." }, 413);
    }

    let body: { imageBase64?: unknown; width?: unknown; height?: unknown };
    try {
      body = JSON.parse(text);
    } catch {
      return json({ error: "Invalid request" }, 400);
    }

    let b64 = typeof body.imageBase64 === "string" ? body.imageBase64 : "";
    if (b64.startsWith("data:")) b64 = b64.slice(b64.indexOf(",") + 1);
    if (!b64 || !/^[A-Za-z0-9+/]+={0,2}$/.test(b64)) {
      return json({ error: "Invalid image data" }, 400);
    }
    const mime = sniffMime(b64);
    if (!mime) return json({ error: "Only PNG, JPEG or WebP images are supported." }, 415);

    const result = await convertWhiteboardImage({
      imageBase64: b64,
      mimeType: mime,
      width: clampDim(body.width, 1200),
      height: clampDim(body.height, 800),
    });
    return json(result, 200);
  } catch (err) {
    if (err instanceof UserFacingError) return json({ error: err.message }, err.status);
    console.error("Image conversion API error:", err);
    return json({ error: "Image conversion failed. Please try again." }, 500);
  }
}
