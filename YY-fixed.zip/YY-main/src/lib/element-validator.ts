/**
 * Defensive sanitizer for whiteboard data that comes from outside the app
 * (imported JSON, pasted clipboard data, IndexedDB records, AI output).
 * It never throws: bad values are clamped or removed, unusable elements are dropped.
 * A plain-JS mirror lives in public/whiteboard-store.js (Store.sanitizeElements) — keep both in sync.
 */

export const MAX_ELEMENTS = 20000;
const MAX_POINTS = 50000;
const MAX_TEXT = 100000;
const MAX_DATA_URL = 15_000_000;
const COORD_LIMIT = 1_000_000;
const FORBIDDEN_KEYS = new Set(["__proto__", "constructor", "prototype"]);

const SAFE_COLOR =
  /^(#[0-9a-fA-F]{3,8}|(?:rgb|hsl)a?\([0-9.,%\s/-]{1,60}\)|[a-zA-Z]{3,30})$/;
const SAFE_FONT = /^[A-Za-z0-9 ,'"\-_.]{1,120}$/;
const SAFE_TYPE = /^[A-Za-z]{1,32}$/;
const SAFE_IMAGE_DATA_URL = /^data:image\/(?:png|jpe?g|webp|gif);base64,/;
const SAFE_THUMB_DATA_URL = /^data:image\/(?:png|jpe?g|webp);base64,/;

const NUMERIC_LIMITS: Record<string, [number, number]> = {
  x: [-COORD_LIMIT, COORD_LIMIT],
  y: [-COORD_LIMIT, COORD_LIMIT],
  w: [-COORD_LIMIT, COORD_LIMIT],
  h: [-COORD_LIMIT, COORD_LIMIT],
  startX: [-COORD_LIMIT, COORD_LIMIT],
  startY: [-COORD_LIMIT, COORD_LIMIT],
  endX: [-COORD_LIMIT, COORD_LIMIT],
  endY: [-COORD_LIMIT, COORD_LIMIT],
  pinX: [-COORD_LIMIT, COORD_LIMIT],
  pinY: [-COORD_LIMIT, COORD_LIMIT],
  left: [-COORD_LIMIT, COORD_LIMIT],
  scroll: [-COORD_LIMIT, COORD_LIMIT],
  rotation: [-100000, 100000],
  width: [0, 1000],
  baseWidth: [0, 1000],
  boxWidth: [0, COORD_LIMIT],
  minH: [0, COORD_LIMIT],
  size: [1, 1000],
  opacity: [0, 1],
  inkMul: [0, 100],
  cometCut: [0, 1000],
  duration: [0, 1e9],
  elapsed: [0, 1e9],
  elapsedOffset: [0, 1e9],
  startAt: [0, 1e15],
  endAt: [0, 1e15],
};

const COLOR_KEYS = ["color", "bg", "fillColor", "strokeColor"];

function isPlainObject(v: unknown): v is Record<string, unknown> {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

export function isSafeColor(v: unknown): v is string {
  return typeof v === "string" && SAFE_COLOR.test(v.trim());
}

export function sanitizeElement(input: unknown): Record<string, unknown> | null {
  if (!isPlainObject(input)) return null;
  const type = input["type"];
  if (typeof type !== "string" || !SAFE_TYPE.test(type)) return null;

  const out: Record<string, unknown> = {};
  for (const key of Object.keys(input)) {
    if (FORBIDDEN_KEYS.has(key) || key.startsWith("_") || key === "img") continue;
    const val = input[key];
    if (typeof val === "function") continue;
    out[key] = val;
  }

  if (typeof out["id"] !== "string" && typeof out["id"] !== "number") delete out["id"];
  else out["id"] = String(out["id"]).slice(0, 100);

  for (const [key, [min, max]] of Object.entries(NUMERIC_LIMITS)) {
    if (!(key in out)) continue;
    const n = out[key];
    if (typeof n !== "number" || !Number.isFinite(n)) {
      delete out[key];
    } else {
      out[key] = Math.min(max, Math.max(min, n));
    }
  }

  for (const key of COLOR_KEYS) {
    if (key in out && !isSafeColor(out[key])) delete out[key];
  }
  if ("font" in out && !(typeof out["font"] === "string" && SAFE_FONT.test(out["font"]))) {
    delete out["font"];
  }
  if ("text" in out) {
    if (typeof out["text"] !== "string") delete out["text"];
    else if ((out["text"] as string).length > MAX_TEXT) {
      out["text"] = (out["text"] as string).slice(0, MAX_TEXT);
    }
  }

  if (type === "image" || "src" in out) {
    const src = out["src"];
    if (
      typeof src !== "string" ||
      src.length > MAX_DATA_URL ||
      !SAFE_IMAGE_DATA_URL.test(src)
    ) {
      if (type === "image") return null;
      delete out["src"];
    }
  }

  if ("points" in out) {
    if (!Array.isArray(out["points"])) {
      delete out["points"];
    } else {
      const pts: unknown[] = [];
      for (const p of (out["points"] as unknown[]).slice(0, MAX_POINTS)) {
        if (isPlainObject(p)) {
          const x = p["x"];
          const y = p["y"];
          if (
            typeof x === "number" &&
            typeof y === "number" &&
            Number.isFinite(x) &&
            Number.isFinite(y)
          ) {
            const copy: Record<string, unknown> = {};
            for (const k of Object.keys(p)) {
              if (!FORBIDDEN_KEYS.has(k)) copy[k] = p[k];
            }
            copy["x"] = Math.min(COORD_LIMIT, Math.max(-COORD_LIMIT, x));
            copy["y"] = Math.min(COORD_LIMIT, Math.max(-COORD_LIMIT, y));
            pts.push(copy);
          }
        } else if (typeof p === "number" && Number.isFinite(p)) {
          pts.push(p);
        }
      }
      out["points"] = pts;
    }
  }

  return out;
}

export function sanitizeElements(input: unknown): Record<string, unknown>[] {
  if (!Array.isArray(input)) return [];
  const result: Record<string, unknown>[] = [];
  for (const raw of input.slice(0, MAX_ELEMENTS)) {
    const clean = sanitizeElement(raw);
    if (clean) result.push(clean);
  }
  return result;
}

export function sanitizeThumb(v: unknown): string | null {
  return typeof v === "string" && v.length <= MAX_DATA_URL && SAFE_THUMB_DATA_URL.test(v)
    ? v
    : null;
}

export function sanitizeBoardName(v: unknown): string {
  const s = typeof v === "string" ? v.replace(/[\u0000-\u001f\u007f]/g, "").trim() : "";
  return s.slice(0, 200) || "Untitled";
}
